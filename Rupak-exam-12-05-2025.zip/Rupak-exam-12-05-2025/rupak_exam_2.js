for (i=1; i<=8; i++){
    // document.writeln(i)
    for (j=1; j<=7; j++)
    document.writeln(i*j); 
    document.writeln('<br>');
}